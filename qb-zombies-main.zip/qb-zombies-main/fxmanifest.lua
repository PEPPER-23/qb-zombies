fx_version 'cerulean'
games { 'gta5' }

author 'PokieWizard'
description 'Zombie System for QB-Core Framework'
version '1.3.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

lua54 'yes'