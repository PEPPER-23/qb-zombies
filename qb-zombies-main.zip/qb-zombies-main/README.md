This is a zombie system, converted from ESX
* Loot from zombies (Weapons, items and money)
* Loot probability
* Follow the closest player
* Hordes
* Zombie attack proximity
* Safe Zones


## How install
1. Download the github repository
2. Drop the files in your [resource] folder
3. Don't forget add `ensure qb-zombies` in your server.cfg file
4. Configure to your liking

## Screenshots
![Image description](https://i.imgur.com/D5DvLeg.png)
